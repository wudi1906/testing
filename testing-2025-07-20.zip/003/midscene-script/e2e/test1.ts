let str1:any = "hello world";
const str2: any  = "hello world";
