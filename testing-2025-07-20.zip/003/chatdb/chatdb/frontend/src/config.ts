// API基础URL
export const API_BASE_URL = '/api/v1';
