# """
# 增强的智能体服务 - 重构后的版本
# 提供向后兼容的接口，内部使用新的智能体架构
# """
#
# # 向后兼容的导入
# from app.agents.hybrid_sql_generator import HybridSqlGeneratorAgent
#
# # 导出类以保持向后兼容性
# __all__ = ['HybridSqlGeneratorAgent']
