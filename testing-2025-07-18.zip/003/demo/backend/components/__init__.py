# Components package for file processing and markdown extraction
