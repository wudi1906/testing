# API路径修复文档

## 问题描述

在前端执行脚本时，发现SSE（Server-Sent Events）连接请求的路径缺少`/api/v1`前缀，导致404错误：

```
INFO:     127.0.0.1:63203 - "POST /api/v1/web/scripts/64fac475-eae2-447f-827f-49f18493fbd7/execute HTTP/1.1" 200 OK
INFO:     127.0.0.1:63203 - "GET /web/scripts/stream/exec_64fac475-eae2-447f-827f-49f18493fbd7_1749353198 HTTP/1.1" 404 Not Found
```

## 问题分析

### 1. API路径配置

前端API配置正确：
```typescript
const API_BASE_URL = 'http://localhost:8000';
const API_VERSION = '/api/v1';

const apiClient = axios.create({
  baseURL: `${API_BASE_URL}${API_VERSION}`, // http://localhost:8000/api/v1
  // ...
});
```

### 2. 问题根源

所有通过`apiClient`的请求都正确包含了`/api/v1`前缀，但是SSE连接直接使用了`API_BASE_URL`：

**修复前（错误）：**
```typescript
const eventSource = new EventSource(`${API_BASE_URL}/web/scripts/stream/${sessionId}`);
// 结果: http://localhost:8000/web/scripts/stream/session-id
```

**修复后（正确）：**
```typescript
const eventSource = new EventSource(`${API_BASE_URL}/api/v1/web/scripts/stream/${sessionId}`);
// 结果: http://localhost:8000/api/v1/web/scripts/stream/session-id
```

## 修复内容

### 文件修改

**文件：** `frontend/src/services/api.ts`

**修改位置：** 第764行

**修改内容：**
```diff
- const eventSource = new EventSource(`${API_BASE_URL}/web/scripts/stream/${sessionId}`);
+ const eventSource = new EventSource(`${API_BASE_URL}/api/v1/web/scripts/stream/${sessionId}`);
```

### 影响范围

这个修复影响以下功能：
- 脚本执行的实时状态监控
- SSE流式数据接收
- 执行日志的实时显示
- 进度更新的实时推送

## 验证方法

### 1. 后端日志验证

修复后，后端日志应该显示：
```
INFO: POST /api/v1/web/scripts/{script-id}/execute HTTP/1.1" 200 OK
INFO: GET /api/v1/web/scripts/stream/{session-id} HTTP/1.1" 200 OK
```

而不是：
```
INFO: POST /api/v1/web/scripts/{script-id}/execute HTTP/1.1" 200 OK
INFO: GET /web/scripts/stream/{session-id} HTTP/1.1" 404 Not Found
```

### 2. 前端功能验证

1. **脚本执行测试**：
   - 进入Web模块执行测试页面
   - 选择一个脚本执行
   - 观察右侧状态面板是否正常显示实时状态

2. **SSE连接测试**：
   - 打开浏览器开发者工具
   - 查看Network标签
   - 执行脚本后应该看到SSE连接成功建立

3. **实时日志测试**：
   - 执行脚本过程中
   - 右侧面板应该实时显示执行日志和状态更新

## API路径规范

### 正确的API路径格式

所有API请求都应该包含`/api/v1`前缀：

```
✅ 正确格式：
- POST http://localhost:8000/api/v1/web/scripts/search
- GET  http://localhost:8000/api/v1/web/scripts/statistics
- POST http://localhost:8000/api/v1/web/scripts/{id}/execute
- GET  http://localhost:8000/api/v1/web/scripts/stream/{session-id}

❌ 错误格式：
- POST http://localhost:8000/web/scripts/search
- GET  http://localhost:8000/web/scripts/statistics
- POST http://localhost:8000/web/scripts/{id}/execute
- GET  http://localhost:8000/web/scripts/stream/{session-id}
```

### API分类

1. **脚本管理API（数据库）**：
   ```
   /api/v1/web/scripts/search
   /api/v1/web/scripts/statistics
   /api/v1/web/scripts/{id}
   /api/v1/web/scripts/{id}/execute
   /api/v1/web/scripts/batch-execute
   /api/v1/web/scripts/upload
   ```

2. **脚本执行API（文件系统）**：
   ```
   /api/v1/web/scripts/scripts
   /api/v1/web/scripts/workspace/info
   /api/v1/web/scripts/execute/single
   /api/v1/web/scripts/execute/batch
   /api/v1/web/scripts/sessions
   /api/v1/web/scripts/sessions/{id}
   /api/v1/web/scripts/stream/{session-id}  ← 修复的路径
   ```

## 相关文件

### 前端文件
- `frontend/src/services/api.ts` - API服务配置（已修复）
- `frontend/src/pages/Web/TestExecution/components/ExecutionStatusPanel.tsx` - 使用SSE连接
- `frontend/src/pages/Web/TestExecution/components/ScriptManagementTab.tsx` - 脚本管理
- `frontend/src/pages/Web/TestExecution/components/QuickExecutionTab.tsx` - 快速执行

### 后端文件
- `backend/app/api/v1/endpoints/web/script_management.py` - 脚本管理接口
- `backend/app/api/v1/endpoints/web/script_execution.py` - 脚本执行接口
- `backend/app/api/v1/api.py` - 路由配置

## 测试工具

创建了测试工具来验证API路径配置：
- `frontend/src/utils/api-path-test.ts` - API路径测试工具

使用方法：
```typescript
import { runAllTests } from './utils/api-path-test';

// 在浏览器控制台中运行
runAllTests();
```

## 预防措施

### 1. 代码规范

在创建新的API连接时，确保：
- 使用`apiClient`进行HTTP请求（自动包含前缀）
- 对于SSE连接，手动添加`${API_BASE_URL}/api/v1`前缀
- 对于WebSocket连接，也需要手动添加前缀

### 2. 测试检查

在开发新功能时：
- 检查浏览器Network标签中的请求路径
- 验证后端日志中的路径格式
- 确保所有API请求都返回正确的状态码

### 3. 文档维护

- 更新API文档中的路径示例
- 在代码注释中说明路径格式要求
- 定期检查API路径的一致性

## 总结

这次修复解决了SSE连接路径缺少`/api/v1`前缀的问题，确保了：

1. ✅ **路径一致性**：所有API请求都使用统一的路径格式
2. ✅ **功能完整性**：SSE实时状态监控功能正常工作
3. ✅ **错误消除**：消除了404错误，提升用户体验
4. ✅ **规范统一**：建立了清晰的API路径规范

修复后，前端脚本执行功能的实时状态监控将正常工作，用户可以看到完整的执行过程和实时日志更新。
