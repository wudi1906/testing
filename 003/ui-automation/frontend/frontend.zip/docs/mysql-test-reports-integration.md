# MySQL测试报告集成优化文档

## 优化概述

彻底重构测试报告功能，使用MySQL数据库替代SQLite，并优化报告路径存储和访问机制。

## 核心改进

### 1. 数据库架构升级
- **从SQLite迁移到MySQL**: 使用现有的MySQL数据库连接组件
- **使用现有模型**: 采用 `app.database.models.reports.TestReport` 模型
- **异步数据库操作**: 使用 `db_manager.get_session()` 进行异步操作

### 2. 报告路径优化
- **直接存储路径**: 将 `execution_result['report_path']` 直接存储到数据库
- **生成访问URL**: 自动生成 `/api/v1/web/reports/view/{execution_id}` 访问地址
- **路径验证**: 查询时验证文件是否存在，提供详细错误信息

### 3. 前端集成完善
- **一键查看报告**: 脚本列表中的"报告"按钮直接打开HTML报告
- **新窗口打开**: 避免影响当前操作界面
- **错误处理**: 完善的错误提示和日志记录

## 技术架构

### 数据流程
```
Playwright执行完成 → execution_result['report_path']
                ↓
        test_report_service.save_test_report()
                ↓
        MySQL数据库 (test_reports表)
                ↓
        前端API查询 → 文件路径验证 → 返回HTML报告
```

### 数据库设计 (MySQL)
```sql
CREATE TABLE test_reports (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    script_id VARCHAR(255) NOT NULL,
    script_name VARCHAR(255) NOT NULL,
    session_id VARCHAR(255) NOT NULL,
    execution_id VARCHAR(255) NOT NULL,
    status VARCHAR(50) NOT NULL,
    return_code INT DEFAULT 0,
    start_time DATETIME NULL,
    end_time DATETIME NULL,
    duration DECIMAL(10,3) DEFAULT 0.000,
    total_tests INT DEFAULT 0,
    passed_tests INT DEFAULT 0,
    failed_tests INT DEFAULT 0,
    skipped_tests INT DEFAULT 0,
    success_rate DECIMAL(5,2) DEFAULT 0.00,
    report_path TEXT,           -- 存储HTML报告文件路径
    report_url TEXT,            -- 存储访问URL
    report_size BIGINT DEFAULT 0,
    screenshots JSON,
    videos JSON,
    artifacts JSON,
    error_message TEXT,
    logs JSON,
    execution_config JSON,
    environment_variables JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_script_id (script_id),
    INDEX idx_session_id (session_id),
    INDEX idx_execution_id (execution_id),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

## 核心组件

### 1. 测试报告服务 (test_report_service.py)
```python
class TestReportService:
    async def save_test_report(self, 
                             script_id: str,
                             script_name: str,
                             session_id: str,
                             execution_id: str,
                             status: str,
                             return_code: int,
                             # ... 其他参数
                             report_path: Optional[str] = None,  # 新增
                             report_url: Optional[str] = None    # 新增
                             ) -> Optional[TestReport]:
        """保存测试报告到MySQL数据库"""
        
        # 创建报告记录
        db_report = TestReport(
            script_id=script_id,
            script_name=script_name,
            # ... 其他字段
            report_path=report_path,  # 直接存储报告路径
            report_url=report_url,    # 存储访问URL
        )
        
        # 保存到MySQL数据库
        async with db_manager.get_session() as session:
            session.add(db_report)
            await session.commit()
            await session.refresh(db_report)
            return db_report
    
    async def get_report_file_path(self, execution_id: str) -> Optional[str]:
        """从MySQL获取报告文件路径"""
        async with db_manager.get_session() as session:
            stmt = select(TestReport).filter(TestReport.execution_id == execution_id)
            result = await session.execute(stmt)
            report = result.scalar_one_or_none()
            
            if report and report.report_path:
                if os.path.exists(report.report_path):
                    return report.report_path
                else:
                    logger.warning(f"MySQL中的报告文件不存在: {report.report_path}")
            return None
```

### 2. Playwright执行器集成
```python
class PlaywrightExecutorAgent:
    async def _save_test_report_to_database(self, execution_id: str, message: PlaywrightExecutionRequest, execution_result: Dict[str, Any]):
        """保存测试报告到数据库"""
        
        # 提取报告路径和生成访问URL
        report_path = execution_result.get("report_path")  # 从execution_result获取
        report_url = None
        if report_path:
            report_url = f"/api/v1/web/reports/view/{execution_id}"
            logger.info(f"生成报告访问URL: {report_url} -> {report_path}")
        
        # 保存报告
        saved_report = await test_report_service.save_test_report(
            script_id=script_id,
            script_name=script_name,
            # ... 其他参数
            report_path=report_path,  # 传递报告路径
            report_url=report_url     # 传递访问URL
        )
```

### 3. API接口优化
```python
@router.get("/view/{execution_id}")
async def view_report_html(execution_id: str):
    """查看HTML测试报告"""
    # 获取报告记录
    report = await test_report_service.get_report_by_execution_id(execution_id)
    if not report:
        raise HTTPException(status_code=404, detail=f"未找到执行ID {execution_id} 的测试报告")
    
    # 获取报告文件路径
    report_path = await test_report_service.get_report_file_path(execution_id)
    if not report_path or not os.path.exists(report_path):
        error_msg = f"测试报告文件不存在"
        if report.report_path:
            error_msg += f"，数据库中记录的路径: {report.report_path}"
        raise HTTPException(status_code=404, detail=error_msg)
    
    # 返回HTML文件
    return FileResponse(
        path=report_path,
        media_type="text/html",
        filename=f"test-report-{execution_id}.html"
    )

@router.get("/view/script/{script_id}")
async def view_latest_report_by_script_id(script_id: str):
    """根据脚本ID查看最新的HTML测试报告"""
    # 类似实现，使用 get_report_file_path_by_script_id()
```

## 文件变更

### 删除文件
- `backend/app/models/test_report_simple.py` - 删除临时SQLite模型

### 修改文件
- `backend/app/services/test_report_service.py` - 重构为MySQL版本
- `backend/app/api/v1/endpoints/web/test_reports.py` - 更新为异步MySQL操作
- `backend/app/agents/web/playwright_executor.py` - 优化报告保存逻辑

### 新增文件
- `backend/migrations/create_test_reports_table_mysql.sql` - MySQL建表脚本
- `backend/scripts/init_test_reports_db.py` - MySQL初始化脚本（更新）
- `frontend/docs/mysql-test-reports-integration.md` - 本文档

## 使用流程

### 1. 初始化MySQL数据库
```bash
cd backend
python scripts/init_test_reports_db.py
```

### 2. 执行脚本生成报告
```python
# Playwright执行完成后自动调用
execution_result = {
    "status": "passed",
    "return_code": 0,
    "duration": 5.2,
    "report_path": "/path/to/generated/report.html",  # 关键：报告路径
    # ... 其他结果
}

# 自动保存到MySQL
await self._save_test_report_to_database(execution_id, message, execution_result)
```

### 3. 前端查看报告
```typescript
// 用户点击脚本列表中的"报告"按钮
const handleViewReport = (script) => {
  const reportUrl = `/api/v1/web/reports/view/script/${script.id}`;
  window.open(reportUrl, '_blank');
};
```

## API接口

### 报告查询
- `GET /api/v1/web/reports/script/{script_id}/latest` - 获取最新报告信息
- `GET /api/v1/web/reports/execution/{execution_id}` - 根据执行ID获取报告
- `GET /api/v1/web/reports/list` - 分页获取报告列表

### 报告查看
- `GET /api/v1/web/reports/view/{execution_id}` - 查看HTML报告
- `GET /api/v1/web/reports/view/script/{script_id}` - 查看最新HTML报告

### 报告管理
- `DELETE /api/v1/web/reports/{report_id}` - 删除报告
- `GET /api/v1/web/reports/stats` - 获取统计信息

## 数据库连接

### 使用现有MySQL连接
```python
from app.database.connection import db_manager
from app.database.models.reports import TestReport

# 异步数据库操作
async with db_manager.get_session() as session:
    stmt = select(TestReport).filter(TestReport.script_id == script_id)
    result = await session.execute(stmt)
    report = result.scalar_one_or_none()
```

### 配置要求
- MySQL 5.7+ 或 8.0+
- 支持JSON数据类型
- UTF8MB4字符集
- InnoDB存储引擎

## 优势特性

### 1. 性能优化
- **MySQL索引**: 针对常用查询字段建立索引
- **异步操作**: 使用异步数据库连接，提高并发性能
- **JSON字段**: 高效存储复杂数据结构

### 2. 数据完整性
- **外键约束**: 可扩展关联其他表
- **事务支持**: 确保数据一致性
- **自动时间戳**: 自动维护创建和更新时间

### 3. 扩展性
- **分页查询**: 支持大量报告数据
- **条件过滤**: 支持按状态、脚本ID等过滤
- **统计分析**: 支持复杂的统计查询

### 4. 可维护性
- **标准SQL**: 使用标准MySQL语法
- **清晰架构**: 分层设计，职责明确
- **完善日志**: 详细的操作日志和错误信息

## 验证测试

### 1. 数据库连接测试
```bash
python scripts/init_test_reports_db.py
```

### 2. 报告保存测试
```python
# 执行Playwright脚本，验证报告自动保存
```

### 3. 前端查看测试
```bash
# 访问前端，点击脚本列表中的"报告"按钮
# 验证能正确打开HTML报告
```

### 4. API接口测试
```bash
# 测试报告查询
curl http://localhost:8000/api/v1/web/reports/list

# 测试报告查看
curl http://localhost:8000/api/v1/web/reports/view/script/test_001
```

## 总结

这次优化实现了完整的MySQL测试报告集成：

1. ✅ **MySQL数据库**: 使用现有的MySQL连接组件和模型
2. ✅ **报告路径存储**: 直接存储`execution_result['report_path']`
3. ✅ **访问URL生成**: 自动生成报告访问地址
4. ✅ **前端集成**: 一键查看HTML报告功能
5. ✅ **异步操作**: 高性能的异步数据库操作
6. ✅ **错误处理**: 完善的错误提示和日志记录
7. ✅ **数据完整性**: 使用MySQL的事务和约束特性

现在用户可以在执行Playwright脚本后，直接在前端脚本列表中点击"报告"按钮查看详细的HTML测试报告，所有数据都存储在MySQL数据库中！
