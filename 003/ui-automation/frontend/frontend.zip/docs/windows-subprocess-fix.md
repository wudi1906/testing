# Windows子进程NotImplementedError修复文档

## 问题描述

在Windows系统上执行Playwright脚本时出现错误：
```
NotImplementedError()
```

## 问题分析

### 根本原因
在Windows系统上，`asyncio.create_subprocess_exec`可能会抛出`NotImplementedError`，这是由于：

1. **事件循环策略问题**: Windows上的默认事件循环策略可能不支持子进程
2. **权限问题**: Windows上的进程创建权限限制
3. **路径问题**: Windows路径格式与Unix系统不同

### 错误位置
```python
# 第290行 - 问题代码
process = await asyncio.create_subprocess_exec(
    *command,
    cwd=self.playwright_workspace,
    stdout=asyncio.subprocess.PIPE,
    stderr=asyncio.subprocess.PIPE,
    env=env
)
```

## 修复方案

### 1. 平台检测 + 条件执行
使用`platform.system()`检测操作系统，在Windows上使用同步`subprocess.run`，在其他系统上使用异步`asyncio.create_subprocess_exec`。

### 2. Windows同步执行
```python
import platform

if platform.system() == "Windows":
    # Windows系统使用同步subprocess
    result = subprocess.run(
        command,
        cwd=self.playwright_workspace,
        capture_output=True,
        text=True,
        env=env,
        timeout=300  # 5分钟超时
    )
    
    return_code = result.returncode
    stdout_lines = result.stdout.splitlines() if result.stdout else []
    stderr_lines = result.stderr.splitlines() if result.stderr else []
```

### 3. 非Windows异步执行
```python
else:
    # 非Windows系统使用异步subprocess
    process = await asyncio.create_subprocess_exec(
        *command,
        cwd=self.playwright_workspace,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=env
    )
    
    # 异步读取输出...
```

## 修复后的完整代码

```python
# 在Windows上使用同步subprocess避免NotImplementedError
import platform
if platform.system() == "Windows":
    # Windows系统使用同步subprocess
    try:
        result = subprocess.run(
            command,
            cwd=self.playwright_workspace,
            capture_output=True,
            text=True,
            env=env,
            timeout=300  # 5分钟超时
        )
        
        return_code = result.returncode
        stdout_lines = result.stdout.splitlines() if result.stdout else []
        stderr_lines = result.stderr.splitlines() if result.stderr else []
        
        # 记录和发送输出信息
        for line in stdout_lines:
            if line.strip():
                record["logs"].append(f"[STDOUT] {line}")
                await self.send_response(f"📝 {line}")
                logger.info(f"[Playwright] {line}")
        
        for line in stderr_lines:
            if line.strip():
                record["logs"].append(f"[STDERR] {line}")
                await self.send_response(f"⚠️ {line}")
                logger.warning(f"[Playwright Error] {line}")
                
    except subprocess.TimeoutExpired:
        logger.error("Playwright测试执行超时")
        raise Exception("测试执行超时（5分钟）")
        
else:
    # 非Windows系统使用异步subprocess
    process = await asyncio.create_subprocess_exec(
        *command,
        cwd=self.playwright_workspace,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=env
    )

    # 实时读取输出
    stdout_lines = []
    stderr_lines = []

    async def read_stdout():
        async for line in process.stdout:
            line_text = line.decode('utf-8').strip()
            if line_text:
                stdout_lines.append(line_text)
                record["logs"].append(f"[STDOUT] {line_text}")
                await self.send_response(f"📝 {line_text}")
                logger.info(f"[Playwright] {line_text}")

    async def read_stderr():
        async for line in process.stderr:
            line_text = line.decode('utf-8').strip()
            if line_text:
                stderr_lines.append(line_text)
                record["logs"].append(f"[STDERR] {line_text}")
                await self.send_response(f"⚠️ {line_text}")
                logger.warning(f"[Playwright Error] {line_text}")

    # 并发读取输出
    await asyncio.gather(read_stdout(), read_stderr())

    # 等待进程完成
    return_code = await process.wait()
```

## 修复优势

### 1. 跨平台兼容性
- **Windows**: 使用稳定的同步`subprocess.run`
- **Linux/macOS**: 使用高效的异步`asyncio.create_subprocess_exec`

### 2. 错误处理增强
- **超时控制**: Windows版本添加5分钟超时
- **异常捕获**: 专门处理`subprocess.TimeoutExpired`
- **日志记录**: 统一的日志格式和错误报告

### 3. 功能保持
- **实时输出**: 两种方式都能实时显示执行输出
- **错误捕获**: 完整捕获stdout和stderr
- **状态报告**: 通过SSE实时推送执行状态

## 测试验证

### 1. Windows环境测试
```bash
# 确保在Windows上能正常执行
python -c "import platform; print(platform.system())"  # 应该输出 "Windows"

# 测试脚本执行
# 前端发起执行请求，观察日志输出
```

### 2. 非Windows环境测试
```bash
# 在Linux/macOS上测试异步执行
python -c "import platform; print(platform.system())"  # 应该输出 "Linux" 或 "Darwin"

# 测试异步子进程功能
```

### 3. 功能验证
- ✅ 脚本能正常执行
- ✅ 实时输出正常显示
- ✅ 错误信息正确捕获
- ✅ 执行状态正确报告
- ✅ 超时机制正常工作

## 修改文件清单

### 后端文件
- `backend/app/agents/web/playwright_executor.py`
  - 第289-360行: 替换子进程执行逻辑
  - 添加平台检测和条件执行
  - 增强错误处理和超时控制

## 预期结果

修复后在Windows上应该看到：
```
INFO: 找到现有脚本文件: C:\Users\86134\Desktop\workspace\playwright-workspace\e2e\test_20250608_121848.spec.ts
INFO: 使用现有脚本文件: C:\Users\86134\Desktop\workspace\playwright-workspace\e2e\test_20250608_121848.spec.ts
INFO: 执行命令: npx playwright test e2e/test_20250608_121848.spec.ts
INFO: 工作目录: C:\Users\86134\Desktop\workspace\playwright-workspace
INFO: [Playwright] Running 1 test using 1 worker
INFO: [Playwright] ✓ test_20250608_121848.spec.ts:3:1 › example test (2.5s)
INFO: [Playwright] 1 passed (3.2s)
INFO: Playwright测试执行完成: passed
```

而不是：
```
ERROR: NotImplementedError()
```

## 技术要点

### 1. 平台检测
```python
import platform
if platform.system() == "Windows":
    # Windows特定逻辑
else:
    # 其他平台逻辑
```

### 2. 同步vs异步
- **同步**: 简单可靠，适合Windows
- **异步**: 高效并发，适合服务器环境

### 3. 超时处理
```python
try:
    result = subprocess.run(..., timeout=300)
except subprocess.TimeoutExpired:
    raise Exception("测试执行超时（5分钟）")
```

## 总结

这次修复解决了Windows系统上的`NotImplementedError`问题：

1. ✅ **平台兼容**: 根据操作系统选择合适的子进程执行方式
2. ✅ **错误处理**: 增强超时控制和异常捕获
3. ✅ **功能保持**: 保持实时输出和状态报告功能
4. ✅ **性能优化**: Windows用同步，其他平台用异步

修复后，Playwright执行智能体应该能在Windows系统上正常工作，不再出现`NotImplementedError`错误。
