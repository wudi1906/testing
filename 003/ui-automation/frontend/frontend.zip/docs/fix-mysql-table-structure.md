# 修复MySQL表结构问题

## 问题描述

执行测试报告功能时出现错误：
```
OperationalError('(pymysql.err.OperationalError) (1054, "Unknown column \'session_id\' in \'field list\'")') 
```

## 问题原因

MySQL数据库中的`test_reports`表结构与代码中的模型不匹配，缺少必要的字段。

## 解决方案

### 方案1: 使用快速修复脚本（推荐）

```bash
cd backend
python scripts/quick_fix_db.py
```

这个脚本会：
1. 删除现有的`test_reports`表
2. 重新创建完整的表结构
3. 插入测试数据验证
4. 运行测试确保表正常工作

### 方案2: 直接执行SQL文件

```bash
# 连接到MySQL数据库
mysql -u your_username -p your_database_name

# 执行修复SQL
source backend/scripts/fix_test_reports_table.sql;
```

### 方案3: 使用详细检查脚本

```bash
cd backend
python scripts/create_test_reports_table.py
```

这个脚本会：
1. 检查表是否存在
2. 分析现有表结构
3. 提示缺少的字段
4. 可选择重新创建表

## 表结构说明

修复后的`test_reports`表包含以下字段：

### 基本信息
- `id`: 主键，自增
- `script_id`: 脚本ID
- `script_name`: 脚本名称
- `session_id`: 执行会话ID
- `execution_id`: 执行ID

### 执行结果
- `status`: 执行状态 (passed/failed/error)
- `return_code`: 返回码
- `start_time`: 开始时间
- `end_time`: 结束时间
- `duration`: 执行时长

### 测试统计
- `total_tests`: 总测试数
- `passed_tests`: 通过测试数
- `failed_tests`: 失败测试数
- `skipped_tests`: 跳过测试数
- `success_rate`: 成功率

### 报告文件
- `report_path`: 报告文件路径
- `report_url`: 报告访问URL
- `report_size`: 报告文件大小

### 产物信息 (JSON格式)
- `screenshots`: 截图文件列表
- `videos`: 视频文件列表
- `artifacts`: 其他产物文件列表

### 错误和日志
- `error_message`: 错误信息
- `logs`: 执行日志 (JSON格式)

### 环境信息 (JSON格式)
- `execution_config`: 执行配置
- `environment_variables`: 环境变量

### 元数据
- `created_at`: 创建时间
- `updated_at`: 更新时间

## 索引

表包含以下索引以提高查询性能：
- `idx_script_id`: 脚本ID索引
- `idx_session_id`: 会话ID索引
- `idx_execution_id`: 执行ID索引
- `idx_status`: 状态索引
- `idx_created_at`: 创建时间索引

## 验证修复

修复完成后，可以通过以下方式验证：

### 1. 检查表结构
```sql
DESCRIBE test_reports;
```

### 2. 查看示例数据
```sql
SELECT id, script_id, script_name, session_id, status, report_path 
FROM test_reports 
LIMIT 5;
```

### 3. 测试应用功能
1. 启动后端服务
2. 执行一个Playwright脚本
3. 检查是否能正常保存报告
4. 在前端查看报告列表

## 常见问题

### Q: 修复后数据丢失了怎么办？
A: 修复脚本会删除现有表，如果有重要数据，请先备份：
```sql
CREATE TABLE test_reports_backup AS SELECT * FROM test_reports;
```

### Q: 修复失败怎么办？
A: 检查以下几点：
1. 数据库连接是否正常
2. 用户是否有CREATE/DROP权限
3. 数据库是否支持JSON类型（MySQL 5.7+）

### Q: 如何恢复备份数据？
A: 如果之前有备份，可以这样恢复：
```sql
INSERT INTO test_reports SELECT * FROM test_reports_backup;
```

## 预防措施

为避免类似问题，建议：

1. **使用数据库迁移**: 在生产环境中使用正式的数据库迁移工具
2. **版本控制**: 将数据库结构变更纳入版本控制
3. **测试环境**: 在测试环境中先验证表结构变更
4. **备份策略**: 定期备份重要数据

## 技术细节

### MySQL版本要求
- MySQL 5.7+ 或 8.0+
- 支持JSON数据类型
- 支持UTF8MB4字符集

### 字符集设置
```sql
DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
```

### 存储引擎
```sql
ENGINE=InnoDB
```

## 总结

通过执行修复脚本，可以解决`session_id`字段缺失的问题，确保测试报告功能正常工作。建议使用快速修复脚本，它会自动处理所有必要的步骤并验证结果。
