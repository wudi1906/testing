# 数据库导入错误修复文档

## 问题描述

在实现测试报告功能时遇到导入错误：
```
Cannot find reference 'database' in 'imported module app.core'
```

## 问题分析

### 根本原因
1. **导入路径错误**: 使用了不存在的 `app.core.database` 模块
2. **数据库架构复杂**: 项目中存在多套数据库连接方式
3. **模型定义分散**: 数据库模型分布在不同目录中

### 错误位置
```python
# 错误的导入
from app.core.database import get_db
from app.database.models.reports import TestReport
```

## 修复方案

### 1. 创建简化的数据库模型
使用独立的SQLAlchemy模型，不依赖复杂的数据库架构：

```python
# app/models/test_report_simple.py
from sqlalchemy import Column, Integer, String, Text, DateTime, Float, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

Base = declarative_base()

class TestReportSimple(Base):
    __tablename__ = "test_reports"
    
    id = Column(Integer, primary_key=True, index=True)
    script_id = Column(String(255), nullable=False, index=True)
    script_name = Column(String(255), nullable=False)
    # ... 其他字段
```

### 2. 简化的数据库管理器
```python
class SimpleDBManager:
    def __init__(self, database_url: str = "sqlite:///test_reports.db"):
        self.database_url = database_url
        self.engine = None
        self.SessionLocal = None
    
    def initialize(self):
        self.engine = create_engine(self.database_url)
        self.SessionLocal = sessionmaker(bind=self.engine)
        Base.metadata.create_all(bind=self.engine)
    
    def get_session(self):
        return self.SessionLocal()
```

### 3. 更新服务层
```python
# 修复前
from app.core.database import get_db
from app.database.models.reports import TestReport

# 修复后
from app.models.test_report_simple import TestReportSimple, simple_db_manager
```

### 4. 更新数据库操作
```python
# 修复前 (异步方式)
async with db_manager.get_session() as session:
    result = await session.execute(stmt)

# 修复后 (同步方式)
db = simple_db_manager.get_session()
try:
    result = db.query(TestReportSimple).filter(...).first()
finally:
    db.close()
```

## 修复后的文件结构

### 新增文件
```
backend/
├── app/
│   ├── models/
│   │   └── test_report_simple.py        # 简化的测试报告模型
│   ├── services/
│   │   └── test_report_service.py       # 测试报告服务（已更新）
│   └── api/v1/endpoints/web/
│       └── test_reports.py              # 测试报告API（已更新）
├── scripts/
│   └── init_test_reports_db.py          # 数据库初始化脚本
└── docs/
    └── database-import-fix.md           # 修复文档
```

### 删除文件
```
backend/app/models/test_report_db.py     # 删除临时文件
backend/app/database/models/reports.py  # 删除复杂模型
```

## 核心修改

### 1. 测试报告服务 (test_report_service.py)
```python
# 修复前
from app.core.database import get_db
from app.database.models.reports import TestReport

async def save_test_report(...) -> Optional[TestReport]:
    async with db_manager.get_session() as session:
        # 异步操作

# 修复后
from app.models.test_report_simple import TestReportSimple, simple_db_manager

async def save_test_report(...) -> Optional[TestReportSimple]:
    db = simple_db_manager.get_session()
    try:
        # 同步操作
    finally:
        db.close()
```

### 2. 测试报告API (test_reports.py)
```python
# 修复前
from app.core.database import get_db
from app.database.models.reports import TestReport

async def list_reports(...):
    async with db_manager.get_session() as session:
        # 复杂的异步查询

# 修复后
from app.models.test_report_simple import TestReportSimple, simple_db_manager

async def list_reports(...):
    db = simple_db_manager.get_session()
    try:
        # 简单的同步查询
    finally:
        db.close()
```

### 3. Playwright执行器 (playwright_executor.py)
```python
# 添加导入
from app.services.test_report_service import test_report_service
from datetime import datetime

# 添加报告保存方法
async def _save_test_report_to_database(self, execution_id: str, message: PlaywrightExecutionRequest, execution_result: Dict[str, Any]):
    # 保存报告逻辑
```

## 数据库设计

### 表结构
```sql
CREATE TABLE test_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    script_id VARCHAR(255) NOT NULL,
    script_name VARCHAR(255) NOT NULL,
    session_id VARCHAR(255) NOT NULL,
    execution_id VARCHAR(255) NOT NULL,
    status VARCHAR(50) NOT NULL,
    return_code INTEGER DEFAULT 0,
    start_time DATETIME,
    end_time DATETIME,
    duration REAL DEFAULT 0.0,
    total_tests INTEGER DEFAULT 0,
    passed_tests INTEGER DEFAULT 0,
    failed_tests INTEGER DEFAULT 0,
    skipped_tests INTEGER DEFAULT 0,
    success_rate REAL DEFAULT 0.0,
    report_path TEXT,
    report_url TEXT,
    report_size INTEGER DEFAULT 0,
    screenshots TEXT,           -- JSON array
    videos TEXT,               -- JSON array
    artifacts TEXT,            -- JSON array
    error_message TEXT,
    logs TEXT,                 -- JSON array
    execution_config TEXT,     -- JSON object
    environment_variables TEXT, -- JSON object
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### 索引
```sql
CREATE INDEX idx_test_reports_script_id ON test_reports(script_id);
CREATE INDEX idx_test_reports_session_id ON test_reports(session_id);
CREATE INDEX idx_test_reports_execution_id ON test_reports(execution_id);
CREATE INDEX idx_test_reports_status ON test_reports(status);
CREATE INDEX idx_test_reports_created_at ON test_reports(created_at);
```

## 初始化步骤

### 1. 运行初始化脚本
```bash
cd backend
python scripts/init_test_reports_db.py
```

### 2. 验证数据库
```python
from app.models.test_report_simple import simple_db_manager, TestReportSimple

# 初始化数据库
simple_db_manager.initialize()

# 测试连接
db = simple_db_manager.get_session()
count = db.query(TestReportSimple).count()
print(f"报告数量: {count}")
db.close()
```

## 优势

### 1. 简化架构
- 独立的数据库模型，不依赖复杂架构
- 直接使用SQLAlchemy，减少抽象层
- 简化的数据库管理器

### 2. 易于维护
- 单一文件包含完整模型定义
- 清晰的数据库操作逻辑
- 独立的初始化脚本

### 3. 高度兼容
- 使用标准SQLAlchemy语法
- 支持SQLite和其他数据库
- 易于扩展和修改

### 4. 错误处理
- 完善的异常处理
- 资源自动清理
- 详细的错误日志

## 测试验证

### 1. 数据库连接测试
```python
# 测试数据库初始化
simple_db_manager.initialize()
assert simple_db_manager._initialized == True

# 测试会话获取
db = simple_db_manager.get_session()
assert db is not None
db.close()
```

### 2. 模型操作测试
```python
# 测试报告创建
report_data = {
    "script_id": "test_001",
    "script_name": "测试脚本",
    # ... 其他数据
}
report = TestReportSimple.from_dict(report_data)
assert report.script_id == "test_001"

# 测试字典转换
report_dict = report.to_dict()
assert "script_id" in report_dict
```

### 3. API接口测试
```bash
# 测试报告列表
curl http://localhost:8000/api/v1/web/reports/list

# 测试报告查看
curl http://localhost:8000/api/v1/web/reports/view/script/test_001
```

## 总结

这次修复解决了数据库导入错误的问题：

1. ✅ **简化架构**: 使用独立的SQLAlchemy模型
2. ✅ **修复导入**: 移除不存在的模块依赖
3. ✅ **统一操作**: 使用一致的数据库操作方式
4. ✅ **完善功能**: 保持所有测试报告功能完整
5. ✅ **易于维护**: 简化的代码结构和清晰的文档

修复后，测试报告功能应该能正常工作，不再出现导入错误。
