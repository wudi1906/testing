# 测试报告集成功能文档

## 功能概述

实现了Playwright测试执行完成后自动保存报告信息到数据库，并在前端脚本列表中提供查看HTML报告的功能。

## 核心功能

### 1. 自动保存测试报告
- 执行完成后自动将报告信息存入数据库
- 包含执行结果、统计信息、文件路径等
- 支持错误信息和日志记录

### 2. 前端查看报告
- 脚本列表操作列新增"报告"按钮
- 点击可在新窗口打开HTML测试报告
- 支持根据脚本ID查看最新报告

## 实现架构

### 后端架构

```
Playwright执行器 → 测试报告服务 → 数据库
                ↓
            报告API接口 → 前端查看
```

### 数据流程

```
1. Playwright执行完成
2. 解析执行结果和日志
3. 查找生成的HTML报告文件
4. 保存报告信息到数据库
5. 前端通过API查看报告
```

## 数据库设计

### TestReport表结构

```sql
CREATE TABLE test_reports (
    id INTEGER PRIMARY KEY,
    script_id VARCHAR(255),      -- 脚本ID
    script_name VARCHAR(255),    -- 脚本名称
    session_id VARCHAR(255),     -- 执行会话ID
    execution_id VARCHAR(255),   -- 执行ID
    status VARCHAR(50),          -- 执行状态
    return_code INTEGER,         -- 返回码
    start_time DATETIME,         -- 开始时间
    end_time DATETIME,           -- 结束时间
    duration REAL,               -- 执行时长
    total_tests INTEGER,         -- 总测试数
    passed_tests INTEGER,        -- 通过测试数
    failed_tests INTEGER,        -- 失败测试数
    skipped_tests INTEGER,       -- 跳过测试数
    success_rate REAL,           -- 成功率
    report_path TEXT,            -- 报告文件路径
    report_url TEXT,             -- 报告访问URL
    report_size INTEGER,         -- 报告文件大小
    screenshots TEXT,            -- 截图文件列表(JSON)
    videos TEXT,                 -- 视频文件列表(JSON)
    artifacts TEXT,              -- 其他产物文件列表(JSON)
    error_message TEXT,          -- 错误信息
    logs TEXT,                   -- 执行日志(JSON)
    execution_config TEXT,       -- 执行配置(JSON)
    environment_variables TEXT,  -- 环境变量(JSON)
    created_at DATETIME,         -- 创建时间
    updated_at DATETIME          -- 更新时间
);
```

## API接口

### 报告查询接口

```typescript
// 根据脚本ID获取最新报告
GET /api/v1/web/reports/script/{script_id}/latest

// 根据执行ID获取报告
GET /api/v1/web/reports/execution/{execution_id}

// 根据会话ID获取所有报告
GET /api/v1/web/reports/session/{session_id}

// 获取报告列表（分页）
GET /api/v1/web/reports/list?page=1&page_size=20

// 获取报告统计信息
GET /api/v1/web/reports/stats
```

### 报告查看接口

```typescript
// 查看HTML报告（根据执行ID）
GET /api/v1/web/reports/view/{execution_id}

// 查看最新HTML报告（根据脚本ID）
GET /api/v1/web/reports/view/script/{script_id}
```

### 报告管理接口

```typescript
// 删除报告
DELETE /api/v1/web/reports/{report_id}
```

## 前端集成

### 脚本管理组件更新

```typescript
// 新增查看报告功能
const handleViewReport = async (script: Script) => {
  const reportUrl = `/api/v1/web/reports/view/script/${script.id}`;
  window.open(reportUrl, '_blank');
};

// 操作列新增报告按钮
<Button
  size="small"
  icon={<FileSearchOutlined />}
  onClick={() => handleViewReport(record)}
  type="primary"
  ghost
>
  报告
</Button>
```

### 报告API服务

```typescript
// 前端API服务
export const getLatestReportByScriptId = async (scriptId: string): Promise<TestReport> => {
  const response = await apiClient.get(`/web/reports/script/${scriptId}/latest`);
  return response.data.data;
};

export const openLatestReportByScriptId = (scriptId: string): void => {
  const url = `/api/v1/web/reports/view/script/${scriptId}`;
  window.open(url, '_blank', 'noopener,noreferrer');
};
```

## 核心服务

### TestReportService

```python
class TestReportService:
    async def save_test_report(self, ...):
        """保存测试报告到数据库"""
        
    async def get_report_by_script_id(self, script_id: str):
        """根据脚本ID获取最新报告"""
        
    def _find_report_files(self, execution_id: str, script_name: str):
        """查找报告文件"""
        
    def _parse_test_results(self, logs: List[str]):
        """解析测试结果统计"""
```

### Playwright执行器集成

```python
class PlaywrightExecutorAgent:
    async def _save_test_report_to_database(self, execution_id: str, message: PlaywrightExecutionRequest, execution_result: Dict[str, Any]):
        """保存测试报告到数据库"""
        
        # 提取脚本信息
        script_id = getattr(message, 'script_id', None) or execution_id
        script_name = message.script_name
        
        # 保存报告
        saved_report = await test_report_service.save_test_report(
            script_id=script_id,
            script_name=script_name,
            session_id=session_id,
            execution_id=execution_id,
            status=status,
            return_code=execution_result.get("return_code", 0),
            # ... 其他参数
        )
```

## 文件结构

### 后端文件

```
backend/
├── app/
│   ├── database/models/
│   │   └── reports.py                    # 测试报告数据模型
│   ├── services/
│   │   └── test_report_service.py        # 测试报告服务
│   ├── api/v1/endpoints/web/
│   │   └── test_reports.py               # 测试报告API接口
│   └── agents/web/
│       └── playwright_executor.py        # Playwright执行器（已更新）
└── migrations/
    └── create_test_reports_table.sql     # 数据库迁移脚本
```

### 前端文件

```
frontend/
├── src/
│   ├── services/
│   │   └── testReportApi.ts              # 测试报告API服务
│   └── pages/Web/TestExecution/components/
│       └── UnifiedScriptManagement.tsx   # 脚本管理组件（已更新）
└── docs/
    └── test-report-integration.md        # 功能文档
```

## 使用流程

### 1. 执行脚本
```typescript
// 前端发起脚本执行
const result = await executeScriptById(scriptId, config);
```

### 2. 自动保存报告
```python
# 后端Playwright执行完成后自动保存
await self._save_test_report_to_database(execution_id, message, execution_result)
```

### 3. 查看报告
```typescript
// 前端点击报告按钮
const handleViewReport = (script) => {
  window.open(`/api/v1/web/reports/view/script/${script.id}`, '_blank');
};
```

## 报告内容

### 自动收集的信息

1. **执行结果**
   - 执行状态（passed/failed/error）
   - 返回码
   - 执行时长

2. **测试统计**
   - 总测试数
   - 通过/失败/跳过测试数
   - 成功率

3. **文件产物**
   - HTML报告文件路径
   - 截图文件列表
   - 视频文件列表
   - 其他产物文件

4. **执行信息**
   - 执行日志
   - 错误信息
   - 执行配置
   - 环境变量

### 报告文件位置

```
playwright-workspace/
└── midscene_run/
    └── report/
        ├── index.html          # 主报告文件
        ├── screenshots/        # 截图目录
        ├── videos/            # 视频目录
        └── artifacts/         # 其他产物
```

## 特性优势

### 1. 自动化
- 无需手动保存报告
- 执行完成自动收集信息
- 自动解析测试结果

### 2. 便捷性
- 一键查看HTML报告
- 新窗口打开，不影响当前操作
- 支持历史报告查看

### 3. 完整性
- 保存完整的执行信息
- 包含错误日志和调试信息
- 支持多种文件产物

### 4. 可扩展性
- 支持报告列表和统计
- 支持报告删除和管理
- 可扩展更多报告功能

## 注意事项

### 1. 文件路径
- 确保Playwright工作空间路径正确
- 报告文件路径需要可访问

### 2. 数据库
- 需要运行迁移脚本创建表
- JSON字段存储复杂数据

### 3. 权限
- 确保后端有文件读取权限
- 前端需要能访问报告接口

### 4. 性能
- 大量报告可能影响查询性能
- 考虑定期清理旧报告

## 总结

这个集成功能实现了从Playwright执行到报告查看的完整流程：

1. ✅ **自动保存**: 执行完成后自动保存报告信息
2. ✅ **数据库存储**: 完整的报告数据模型和存储
3. ✅ **API接口**: 丰富的报告查询和管理接口
4. ✅ **前端集成**: 便捷的报告查看功能
5. ✅ **文件管理**: 自动查找和管理报告文件
6. ✅ **错误处理**: 完善的异常处理和日志记录

用户现在可以在执行脚本后，直接在脚本列表中点击"报告"按钮查看详细的HTML测试报告，大大提升了测试结果的可视化和可访问性。
