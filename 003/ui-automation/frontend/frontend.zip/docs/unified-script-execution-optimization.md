# 统一脚本执行系统优化方案

## 概述

基于用户建议，全新设计了基于脚本ID的前后端数据传输逻辑，实现了统一的脚本执行系统。前端发送脚本ID到后端，后端根据脚本ID获取脚本路径，然后调用脚本执行智能体进行执行。

## 核心设计理念

### 1. 统一接口设计
- **前端**: 只需要发送脚本ID，无需关心脚本的具体位置和类型
- **后端**: 根据脚本ID自动解析脚本路径和信息，调用执行智能体
- **智能路由**: 自动识别数据库脚本和文件系统脚本

### 2. 双数据源支持
- **数据库脚本**: 从数据库获取脚本内容，创建临时文件执行
- **文件系统脚本**: 直接读取工作空间中的.spec.ts文件
- **无缝切换**: 用户无需关心脚本来源，统一的执行体验

### 3. 实时状态监控
- **SSE流式通信**: 实时推送执行状态和日志
- **统一消息格式**: 标准化的消息结构和事件类型
- **智能进度跟踪**: 自动计算和显示执行进度

## 技术架构

### 后端架构

#### 1. 统一执行接口 (`unified_script_execution.py`)

```python
# 核心接口
POST /api/v1/web/unified-execution/execute          # 单脚本执行
POST /api/v1/web/unified-execution/batch-execute    # 批量执行
GET  /api/v1/web/unified-execution/stream/{session_id}  # SSE流
GET  /api/v1/web/unified-execution/sessions         # 会话管理
```

#### 2. 脚本路径解析器

```python
async def resolve_script_path(script_id: str) -> Dict[str, Any]:
    """
    智能脚本路径解析器
    1. 优先从数据库查找脚本
    2. 如果不存在，从文件系统查找
    3. 返回统一的脚本信息结构
    """
    # 尝试数据库脚本
    try:
        db_script = await database_script_service.get_script(script_id)
        if db_script:
            return create_database_script_info(db_script)
    except Exception:
        pass
    
    # 尝试文件系统脚本
    try:
        fs_script = find_filesystem_script(script_id)
        if fs_script:
            return create_filesystem_script_info(fs_script)
    except Exception:
        pass
    
    raise HTTPException(status_code=404, detail=f"脚本不存在: {script_id}")
```

#### 3. 统一执行流程

```python
async def execute_single_unified_script(session_id, script_info, orchestrator, message_queue):
    """
    统一的脚本执行流程
    1. 根据脚本类型创建临时文件（如果需要）
    2. 调用Playwright执行智能体
    3. 实时推送执行状态
    4. 清理临时资源
    """
```

### 前端架构

#### 1. 统一API服务 (`unifiedScriptApi.ts`)

```typescript
// 核心API函数
export const executeScriptById = async (request: ScriptExecutionRequest)
export const batchExecuteScriptsByIds = async (request: BatchScriptExecutionRequest)
export const createUnifiedExecutionSSE = (sessionId: string, callbacks...)

// 便捷函数
export const executeScript = async (scriptId: string, config?, env?)
export const batchExecuteScripts = async (scriptIds: string[], config?, env?)

// 执行监控器
export class UnifiedExecutionMonitor {
  onMessage(callback): this
  onStatusChange(callback): this
  onComplete(callback): this
  start(): this
  stop(): void
  stopExecution(): Promise<void>
}
```

#### 2. 统一管理组件 (`UnifiedScriptManagement.tsx`)

```typescript
// 主要功能
- 双数据源脚本列表展示
- 统一的执行操作界面
- 批量选择和执行
- 实时执行状态监控
- 智能脚本过滤和搜索
```

#### 3. 统一状态面板 (`UnifiedExecutionStatusPanel.tsx`)

```typescript
// 核心功能
- SSE实时连接管理
- 执行消息流显示
- 脚本状态统计
- 进度跟踪和可视化
- 错误处理和重连机制
```

## 数据流程

### 1. 脚本执行流程

```
前端发起执行请求
    ↓
POST /api/v1/web/unified-execution/execute
{
  "script_id": "test-script-001",
  "execution_config": { "base_url": "https://example.com" }
}
    ↓
后端解析脚本路径
    ↓
创建执行会话和临时文件
    ↓
调用Playwright执行智能体
    ↓
返回会话信息
{
  "session_id": "exec_abc123_1749354709",
  "script_name": "test-script-001",
  "script_type": "database",
  "sse_endpoint": "/api/v1/web/unified-execution/stream/exec_abc123_1749354709"
}
    ↓
前端建立SSE连接
    ↓
实时接收执行状态和日志
```

### 2. SSE消息格式

```typescript
interface StreamMessage {
  message_id: string;
  type: 'message' | 'error' | 'progress' | 'final_result';
  source: string;
  content: string;
  timestamp: string;
  region?: string;
  platform?: string;
  is_final?: boolean;
}
```

### 3. 脚本信息结构

```typescript
interface ScriptInfo {
  type: 'database' | 'filesystem';
  script_id: string;
  name: string;
  path: string;
  content: string;
  format: string;
  description: string;
  temp_dir?: string;  // 临时目录（数据库脚本）
}
```

## 核心优势

### 1. 简化的前端逻辑
- **统一接口**: 前端只需要脚本ID，无需区分脚本类型
- **自动路由**: 后端智能识别和处理不同类型的脚本
- **一致体验**: 数据库脚本和文件系统脚本使用相同的执行流程

### 2. 智能的后端处理
- **自动解析**: 根据脚本ID自动查找和解析脚本信息
- **临时文件管理**: 数据库脚本自动创建和清理临时文件
- **统一执行**: 所有脚本都通过相同的执行智能体处理

### 3. 实时的状态监控
- **SSE流式通信**: 低延迟的实时状态推送
- **丰富的消息类型**: 支持多种消息类型和状态更新
- **智能重连**: 自动处理连接断开和重连

### 4. 优秀的用户体验
- **直观的界面**: 清晰的脚本列表和状态显示
- **实时反馈**: 即时的执行状态和进度更新
- **错误处理**: 友好的错误提示和恢复机制

## 文件结构

### 后端文件
```
backend/app/api/v1/endpoints/web/
├── unified_script_execution.py     # 统一执行接口
├── script_management.py            # 脚本管理接口（保留）
└── script_execution.py             # 脚本执行接口（保留）

backend/app/api/v1/
└── api.py                          # 路由配置
```

### 前端文件
```
frontend/src/
├── services/
│   └── unifiedScriptApi.ts         # 统一API服务
├── pages/Web/TestExecution/
│   ├── UnifiedTestExecution.tsx    # 主页面
│   └── components/
│       ├── UnifiedScriptManagement.tsx      # 脚本管理组件
│       └── UnifiedExecutionStatusPanel.tsx  # 状态面板组件
└── docs/
    └── unified-script-execution-optimization.md  # 本文档
```

## 使用示例

### 1. 执行单个脚本

```typescript
import { executeScript, createExecutionMonitor } from './services/unifiedScriptApi';

// 执行脚本
const result = await executeScript('test-script-001', {
  base_url: 'https://example.com',
  headed: false,
  timeout: 90
});

// 监控执行状态
const monitor = createExecutionMonitor(result.session_id)
  .onMessage(msg => console.log('执行消息:', msg))
  .onComplete(() => console.log('执行完成'))
  .start();
```

### 2. 批量执行脚本

```typescript
import { batchExecuteScripts } from './services/unifiedScriptApi';

// 批量执行
const result = await batchExecuteScripts(
  ['script-1', 'script-2', 'script-3'],
  {
    parallel: true,
    continue_on_error: true,
    base_url: 'https://example.com'
  }
);

console.log(`批量执行会话: ${result.session_id}`);
```

## 部署和配置

### 1. 后端配置
- 确保Playwright工作空间路径正确配置
- 数据库连接正常
- SSE支持已启用

### 2. 前端配置
- API基础URL配置正确
- SSE连接支持
- 错误处理和重试机制

### 3. 环境要求
- Python 3.8+
- Node.js 16+
- Playwright环境
- 数据库支持

## 总结

这次优化实现了真正的统一脚本执行系统：

1. ✅ **简化前端逻辑**: 基于脚本ID的统一接口
2. ✅ **智能后端路由**: 自动解析和处理不同类型脚本
3. ✅ **实时状态监控**: SSE流式通信和丰富的状态信息
4. ✅ **优秀用户体验**: 直观的界面和实时反馈
5. ✅ **高度可扩展**: 易于添加新的脚本类型和功能

通过这次优化，用户可以享受到更加简洁、高效、统一的脚本执行体验。
