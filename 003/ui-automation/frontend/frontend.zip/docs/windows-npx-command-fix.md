# Windows NPX命令执行修复文档

## 问题描述

在Windows系统上执行Playwright脚本时出现错误：
```
FileNotFoundError(2, '系统找不到指定的文件。', None, 2, None)
```

**执行参数**:
- `command=['npx', 'playwright', 'test', 'e2e\\test_20250608_121848.spec.ts']`
- `cwd=WindowsPath('C:/Users/86134/Desktop/workspace/playwright-workspace')`

## 问题分析

### 1. NPX命令执行问题
在Windows上，`npx`不是一个可执行文件，而是一个Node.js脚本，需要通过shell来执行。

### 2. 路径分隔符问题
Windows上的路径使用反斜杠`\`，但是`npx playwright`期望使用正斜杠`/`作为路径分隔符。

### 3. 子进程执行方式问题
在Windows上直接使用`subprocess.run(command_list)`无法找到`npx`命令，需要使用`shell=True`。

## 修复方案

### 1. 使用shell=True执行NPX命令

**修复前**:
```python
result = subprocess.run(
    command,  # ['npx', 'playwright', 'test', 'e2e\\test.spec.ts']
    cwd=self.playwright_workspace,
    capture_output=True,
    text=True,
    env=env,
    timeout=300
)
```

**修复后**:
```python
# 在Windows上将命令转换为字符串并使用shell=True
command_str = ' '.join(command)
result = subprocess.run(
    command_str,  # 'npx playwright test e2e/test.spec.ts'
    cwd=self.playwright_workspace,
    capture_output=True,
    text=True,
    env=env,
    timeout=300,
    shell=True  # 关键：Windows上需要shell=True
)
```

### 2. 修复路径分隔符

**修复前**:
```python
relative_test_path = test_file_path.relative_to(self.playwright_workspace)
command = ["npx", "playwright", "test", str(relative_test_path)]
# 结果: ['npx', 'playwright', 'test', 'e2e\\test.spec.ts']  # Windows反斜杠
```

**修复后**:
```python
relative_test_path = test_file_path.relative_to(self.playwright_workspace)
# 在Windows上将反斜杠转换为正斜杠
import platform
if platform.system() == "Windows":
    relative_path_str = str(relative_test_path).replace('\\', '/')
else:
    relative_path_str = str(relative_test_path)
command = ["npx", "playwright", "test", relative_path_str]
# 结果: ['npx', 'playwright', 'test', 'e2e/test.spec.ts']  # 正斜杠
```

### 3. 增强异常处理

**修复前**:
```python
except Exception as e:
    logger.error(f"Playwright测试执行出错：{str(e)}")
    raise Exception("测试执行超时（5分钟）")  # 错误的异常信息
```

**修复后**:
```python
except subprocess.TimeoutExpired:
    logger.error("Playwright测试执行超时")
    raise Exception("测试执行超时（5分钟）")
except Exception as e:
    logger.error(f"Playwright测试执行出错：{str(e)}")
    raise  # 保持原始异常
```

## 修复后的完整代码

```python
# 构建测试命令 - 使用相对路径，在Windows上转换路径分隔符
relative_test_path = test_file_path.relative_to(self.playwright_workspace)
# 在Windows上将反斜杠转换为正斜杠，因为npx playwright期望正斜杠
import platform
if platform.system() == "Windows":
    relative_path_str = str(relative_test_path).replace('\\', '/')
else:
    relative_path_str = str(relative_test_path)
command = ["npx", "playwright", "test", relative_path_str]

# 在Windows上使用同步subprocess避免NotImplementedError
if platform.system() == "Windows":
    # Windows系统使用同步subprocess，需要shell=True来执行npx
    try:
        # 在Windows上将命令转换为字符串并使用shell=True
        command_str = ' '.join(command)
        logger.info(f"Windows执行命令: {command_str}")
        
        result = subprocess.run(
            command_str,
            cwd=self.playwright_workspace,
            capture_output=True,
            text=True,
            env=env,
            timeout=300,  # 5分钟超时
            shell=True  # Windows上需要shell=True来执行npx
        )
        
        return_code = result.returncode
        stdout_lines = result.stdout.splitlines() if result.stdout else []
        stderr_lines = result.stderr.splitlines() if result.stderr else []
        
        # 记录和发送输出信息
        for line in stdout_lines:
            if line.strip():
                record["logs"].append(f"[STDOUT] {line}")
                await self.send_response(f"📝 {line}")
                logger.info(f"[Playwright] {line}")
        
        for line in stderr_lines:
            if line.strip():
                record["logs"].append(f"[STDERR] {line}")
                await self.send_response(f"⚠️ {line}")
                logger.warning(f"[Playwright Error] {line}")
                
    except subprocess.TimeoutExpired:
        logger.error("Playwright测试执行超时")
        raise Exception("测试执行超时（5分钟）")
    except Exception as e:
        logger.error(f"Playwright测试执行出错：{str(e)}")
        raise
```

## 修复验证

### 1. 命令格式验证
**修复前**:
```
command=['npx', 'playwright', 'test', 'e2e\\test_20250608_121848.spec.ts']
执行方式: subprocess.run(command, shell=False)
结果: FileNotFoundError - 找不到npx命令
```

**修复后**:
```
command_str='npx playwright test e2e/test_20250608_121848.spec.ts'
执行方式: subprocess.run(command_str, shell=True)
结果: 成功执行
```

### 2. 路径格式验证
**修复前**: `e2e\\test.spec.ts` (反斜杠，Windows路径)
**修复后**: `e2e/test.spec.ts` (正斜杠，跨平台路径)

### 3. 执行环境验证
- ✅ Windows系统使用`shell=True`
- ✅ 非Windows系统使用异步subprocess
- ✅ 正确的路径分隔符转换
- ✅ 增强的异常处理

## 技术要点

### 1. Windows NPX执行
```bash
# 直接执行 (失败)
npx playwright test  # FileNotFoundError

# 通过shell执行 (成功)
cmd /c "npx playwright test"  # 或使用shell=True
```

### 2. 路径分隔符处理
```python
# Windows路径
path = Path("e2e\\test.spec.ts")

# 转换为跨平台路径
cross_platform_path = str(path).replace('\\', '/')  # "e2e/test.spec.ts"
```

### 3. 平台检测
```python
import platform
if platform.system() == "Windows":
    # Windows特定逻辑
    use_shell = True
    path_separator = '/'  # npx期望正斜杠
else:
    # 其他平台逻辑
    use_shell = False
    path_separator = os.sep
```

## 预期结果

修复后在Windows上应该看到：
```
INFO: 执行命令: npx playwright test e2e/test_20250608_121848.spec.ts
INFO: Windows执行命令: npx playwright test e2e/test_20250608_121848.spec.ts
INFO: 工作目录: C:\Users\86134\Desktop\workspace\playwright-workspace
INFO: [Playwright] Running 1 test using 1 worker
INFO: [Playwright] ✓ e2e/test_20250608_121848.spec.ts:3:1 › example test (2.5s)
INFO: [Playwright] 1 passed (3.2s)
INFO: Playwright测试执行完成: passed
```

而不是：
```
ERROR: FileNotFoundError(2, '系统找不到指定的文件。', None, 2, None)
```

## 修改文件清单

### 后端文件
- `backend/app/agents/web/playwright_executor.py`
  - 第277-285行: 修复路径分隔符转换
  - 第295-306行: 添加shell=True执行方式
  - 第331-336行: 增强异常处理

## 总结

这次修复解决了Windows系统上NPX命令执行的三个关键问题：

1. ✅ **NPX命令执行**: 使用`shell=True`让Windows能找到npx命令
2. ✅ **路径分隔符**: 将Windows反斜杠转换为npx期望的正斜杠
3. ✅ **异常处理**: 正确区分超时和其他异常类型
4. ✅ **跨平台兼容**: 保持非Windows系统的异步执行方式

修复后，Windows系统上的Playwright脚本执行应该能正常工作。
