# 路由冲突解决方案文档

## 问题描述

在前端执行脚本时，发现SSE连接请求返回404错误，经过分析发现是后端路由冲突导致的：

```
INFO: POST /api/v1/web/scripts/{script-id}/execute HTTP/1.1" 200 OK  ✅
INFO: GET /api/v1/web/scripts/stream/{session-id} HTTP/1.1" 404 Not Found  ❌
```

## 根本原因分析

### 1. 路由冲突问题

原始的路由配置存在冲突：

```python
# 脚本管理路由
api_router.include_router(
    script_management_router,
    prefix="/web",           # 匹配 /web/scripts/*
    tags=["Web-脚本管理"]
)

# 脚本执行路由  
api_router.include_router(
    script_execution_router,
    prefix="/web/scripts",   # 也匹配 /web/scripts/*
    tags=["Web-脚本执行"]
)
```

### 2. 路由匹配优先级

FastAPI按照路由注册顺序进行匹配：
1. **脚本管理路由**先注册，前缀`/web`会匹配所有`/web/scripts/*`路径
2. **脚本执行路由**后注册，但其路径已被脚本管理路由拦截
3. 导致SSE端点`/web/scripts/stream/{session_id}`无法访问

### 3. 具体冲突路径

**脚本管理路由** (`prefix="/web"`)：
- `/web/scripts/search` ✅
- `/web/scripts/statistics` ✅  
- `/web/scripts/{id}` ✅
- `/web/scripts/{id}/execute` ✅
- `/web/scripts/batch-execute` ✅
- `/web/scripts/upload` ✅

**脚本执行路由** (`prefix="/web/scripts"`)：
- `/web/scripts/scripts` ❌ (被脚本管理拦截)
- `/web/scripts/workspace/info` ❌ (被脚本管理拦截)
- `/web/scripts/execute/single` ❌ (被脚本管理拦截)
- `/web/scripts/stream/{session_id}` ❌ (被脚本管理拦截)

## 解决方案

### 1. 路由前缀重新设计

将脚本执行路由的前缀从`/web/scripts`改为`/web/execution`，避免路径冲突：

```python
# 脚本管理路由 - 数据库脚本管理
api_router.include_router(
    script_management_router,
    prefix="/web",              # /web/scripts/*
    tags=["Web-脚本管理"]
)

# 脚本执行路由 - 文件系统脚本执行  
api_router.include_router(
    script_execution_router,
    prefix="/web/execution",    # /web/execution/*
    tags=["Web-脚本执行"]
)
```

### 2. 新的API路径映射

**脚本管理API** (数据库脚本)：
```
POST   /api/v1/web/scripts/search
GET    /api/v1/web/scripts/statistics  
GET    /api/v1/web/scripts/{id}
PUT    /api/v1/web/scripts/{id}
DELETE /api/v1/web/scripts/{id}
POST   /api/v1/web/scripts/{id}/execute
POST   /api/v1/web/scripts/batch-execute
POST   /api/v1/web/scripts/upload
POST   /api/v1/web/scripts/save-from-session
```

**脚本执行API** (文件系统脚本)：
```
GET    /api/v1/web/execution/scripts
GET    /api/v1/web/execution/workspace/info
POST   /api/v1/web/execution/execute/single
POST   /api/v1/web/execution/execute/batch
GET    /api/v1/web/execution/sessions
GET    /api/v1/web/execution/sessions/{id}
POST   /api/v1/web/execution/sessions/{id}/stop
DELETE /api/v1/web/execution/sessions/{id}
GET    /api/v1/web/execution/reports/{session_id}
GET    /api/v1/web/execution/stream/{session_id}  ← 修复的SSE端点
```

### 3. 前端API调用更新

更新前端API服务中的脚本执行相关路径：

```typescript
// 修改前 (冲突)
const response = await apiClient.get('/web/scripts/scripts');
const eventSource = new EventSource(`${API_BASE_URL}/api/v1/web/scripts/stream/${sessionId}`);

// 修改后 (无冲突)  
const response = await apiClient.get('/web/execution/scripts');
const eventSource = new EventSource(`${API_BASE_URL}/api/v1/web/execution/stream/${sessionId}`);
```

## 修改文件清单

### 后端文件
- `backend/app/api/v1/api.py` - 路由注册配置

### 前端文件  
- `frontend/src/services/api.ts` - API路径更新

## 验证方法

### 1. 后端日志验证

修复后，后端日志应该显示：
```
INFO: POST /api/v1/web/scripts/{script-id}/execute HTTP/1.1" 200 OK
INFO: GET /api/v1/web/execution/stream/{session-id} HTTP/1.1" 200 OK  ← 修复成功
```

### 2. 前端功能验证

1. **脚本管理功能**：
   - 搜索脚本：`/web/scripts/search` ✅
   - 获取统计：`/web/scripts/statistics` ✅
   - 执行脚本：`/web/scripts/{id}/execute` ✅

2. **脚本执行功能**：
   - 获取脚本列表：`/web/execution/scripts` ✅
   - 执行单个脚本：`/web/execution/execute/single` ✅
   - SSE实时状态：`/web/execution/stream/{session_id}` ✅

### 3. SSE连接测试

在浏览器开发者工具中验证：
- Network标签应显示SSE连接成功建立
- 执行脚本时右侧状态面板应实时更新

## 功能分离说明

### 脚本管理 (`/web/scripts/*`)
- **用途**: 数据库脚本的CRUD操作
- **特点**: 持久化存储，支持元数据管理
- **主要功能**: 搜索、统计、上传、执行数据库脚本

### 脚本执行 (`/web/execution/*`)  
- **用途**: 文件系统脚本的实时执行
- **特点**: 直接读取工作空间文件，实时监控
- **主要功能**: 执行.spec.ts文件，SSE状态推送，报告管理

## 扩展性考虑

### 1. 清晰的功能边界
- 数据库脚本管理与文件系统脚本执行完全分离
- 避免功能混淆和路由冲突

### 2. 未来扩展空间
- 可以在`/web/execution/`下添加更多执行相关功能
- 可以在`/web/scripts/`下添加更多管理相关功能

### 3. 一致的命名规范
- 管理类功能使用`/scripts/`路径
- 执行类功能使用`/execution/`路径

## 总结

通过将脚本执行路由前缀从`/web/scripts`改为`/web/execution`，成功解决了路由冲突问题：

1. ✅ **消除路由冲突**: 两个功能模块使用不同的路径前缀
2. ✅ **修复SSE连接**: SSE端点现在可以正常访问
3. ✅ **功能清晰分离**: 脚本管理与脚本执行功能边界明确
4. ✅ **保持向后兼容**: 脚本管理API路径保持不变
5. ✅ **提升可维护性**: 清晰的路由结构便于后续维护

修复后，用户可以正常使用脚本执行功能的实时状态监控，SSE连接将正常工作，右侧执行状态面板将显示完整的实时执行信息。
