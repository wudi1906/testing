# 基于脚本ID的执行逻辑修复文档

## 问题分析

### 1. 路由配置问题
**问题**: 前端实际使用的是旧的`TestExecution.tsx`页面，而不是新创建的`UnifiedTestExecution.tsx`页面。

**原因**: 
- 路由配置指向旧页面：`/test/execution` → `TestExecution.tsx`
- 新的统一页面没有被路由系统使用
- 旧页面使用的是旧的API接口，不是统一执行接口

### 2. 脚本路径解析问题
**问题**: 后端创建临时文件，但Playwright执行智能体期望在工作空间中找到脚本。

**原因**:
- 数据库脚本存储的路径默认在工作空间目录下存在
- 不需要创建临时文件，直接使用数据库中存储的路径即可
- 临时文件路径与Playwright工作空间路径不匹配

### 3. 智能体属性错误
**问题**: `'PlaywrightExecutorAgent' object has no attribute 'metrics'`

**原因**: 代码中使用了`self.metrics`，但应该使用`self.performance_metrics`

## 修复方案

### 1. 路由配置修复

**前端路由更新**:
```typescript
// 新的路由配置
<Route path="execution" element={<UnifiedTestExecution />} />           // 新的默认版本
<Route path="execution-legacy" element={<TestExecution />} />           // 旧版本保留
<Route path="execution-optimized" element={<WebTestExecutionOptimized />} /> // 优化版本
```

**修改文件**:
- `frontend/src/App.tsx` - 主应用路由
- `frontend/src/pages/Web/index.tsx` - Web模块路由

### 2. 脚本路径解析优化

**后端逻辑简化**:
```python
async def resolve_script_path(script_id: str) -> Dict[str, Any]:
    # 数据库脚本：直接使用存储的路径，不创建临时文件
    if db_script:
        script_path = PLAYWRIGHT_WORKSPACE / "e2e" / db_script.name
        if not script_path.exists():
            script_path = PLAYWRIGHT_WORKSPACE / "e2e" / f"{db_script.name}.spec.ts"
        
        return {
            "type": "database",
            "script_id": script_id,
            "name": db_script.name,
            "path": str(script_path),
            "file_name": script_path.name  # 关键：返回文件名
        }
```

**执行逻辑统一**:
```python
# 统一使用文件名，让Playwright执行智能体在工作空间中查找
playwright_request = PlaywrightExecutionRequest(
    session_id=session_id,
    script_name=script_info["file_name"],  # 使用文件名而不是完整路径
    execution_config=session_info["execution_config"]
)
```

### 3. 智能体属性修复

**PlaywrightExecutorAgent修复**:
```python
# 修复前
"metrics": self.metrics  # ❌ 错误

# 修复后  
"performance_metrics": self.performance_metrics  # ✅ 正确
```

**智能体路径处理增强**:
```python
async def _get_existing_script_path(self, script_name: str) -> Path:
    # 支持绝对路径
    if os.path.isabs(script_name):
        script_path = Path(script_name)
        if script_path.exists():
            return script_path
    
    # 在e2e目录中查找
    e2e_dir = self.playwright_workspace / "e2e"
    script_path = e2e_dir / script_name
    if script_path.exists():
        return script_path
```

## 修复后的执行流程

### 1. 完整的执行链路

```
前端发起请求
    ↓
POST /api/v1/web/unified-execution/execute
{
  "script_id": "Playwright脚本_20250608_121848",
  "execution_config": { "base_url": "https://example.com" }
}
    ↓
后端解析脚本路径
- 从数据库获取脚本信息
- 验证工作空间中的脚本文件存在
- 返回文件名（不是完整路径）
    ↓
创建执行会话
- 生成session_id
- 注册到active_sessions
- 初始化脚本状态
    ↓
调用Playwright执行智能体
- 使用文件名在工作空间中查找脚本
- 执行脚本并推送实时状态
    ↓
前端接收SSE流
- 实时显示执行状态和日志
- 监控执行进度
```

### 2. API路径映射

**统一执行接口**:
```
POST /api/v1/web/unified-execution/execute          # 单脚本执行
POST /api/v1/web/unified-execution/batch-execute    # 批量执行
GET  /api/v1/web/unified-execution/stream/{session_id}  # SSE流
GET  /api/v1/web/unified-execution/sessions         # 会话管理
```

**前端页面路由**:
```
/test/execution                    # 统一执行页面（新默认）
/web/execution                     # Web模块统一执行页面
/test/execution-legacy             # 旧版本页面（保留）
/test/execution-optimized          # 优化版本页面
```

## 修改文件清单

### 后端文件
1. **`backend/app/api/v1/endpoints/web/unified_script_execution.py`**
   - 修复脚本路径解析逻辑
   - 移除临时文件创建
   - 统一使用文件名执行

2. **`backend/app/agents/web/playwright_executor.py`**
   - 修复metrics属性错误
   - 增强路径处理支持绝对路径

### 前端文件
1. **`frontend/src/App.tsx`**
   - 更新主应用路由配置
   - 设置统一执行页面为默认

2. **`frontend/src/pages/Web/index.tsx`**
   - 更新Web模块路由配置
   - 保留旧版本页面作为legacy

3. **`frontend/src/pages/Web/TestExecution/UnifiedTestExecution.tsx`**
   - 新的统一执行页面（已存在）

4. **`frontend/src/services/unifiedScriptApi.ts`**
   - 统一API服务（已存在）

## 验证方法

### 1. 路由验证
访问以下URL确认路由正确：
- `http://localhost:3000/test/execution` → 统一执行页面
- `http://localhost:3000/web/execution` → 统一执行页面
- `http://localhost:3000/test/execution-legacy` → 旧版本页面

### 2. API验证
检查浏览器Network标签：
- 执行请求：`POST /api/v1/web/unified-execution/execute`
- SSE连接：`GET /api/v1/web/unified-execution/stream/{session_id}`

### 3. 功能验证
1. **脚本列表加载**: 能正常显示数据库和文件系统脚本
2. **脚本执行**: 点击执行按钮能成功启动执行
3. **实时状态**: 右侧面板能实时显示执行状态和日志
4. **错误处理**: 不再出现脚本文件不存在的错误

## 预期结果

修复后应该看到：
```
INFO: POST /api/v1/web/unified-execution/execute HTTP/1.1" 200 OK
INFO: 创建脚本执行会话: exec_xxx - Playwright脚本_20250608_121848 (database)
INFO: 找到现有脚本文件: C:\Users\86134\Desktop\workspace\playwright-workspace\e2e\Playwright脚本_20250608_121848.spec.ts
INFO: GET /api/v1/web/unified-execution/stream/exec_xxx HTTP/1.1" 200 OK
INFO: 开始脚本执行SSE流: exec_xxx
```

而不是：
```
ERROR: 获取脚本文件路径失败: 脚本文件不存在: Playwright脚本_20250608_121848
ERROR: 'PlaywrightExecutorAgent' object has no attribute 'metrics'
```

## 总结

这次修复解决了三个关键问题：

1. ✅ **路由配置**: 前端现在使用正确的统一执行页面和API
2. ✅ **脚本路径**: 后端直接使用工作空间中的脚本文件，不创建临时文件
3. ✅ **智能体错误**: 修复了metrics属性错误和路径处理问题

修复后，基于脚本ID的统一执行系统将正常工作，用户可以享受到简洁、高效的脚本执行体验。
