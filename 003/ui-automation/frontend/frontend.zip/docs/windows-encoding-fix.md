# Windows编码问题修复文档

## 问题描述

在Windows系统上执行Playwright脚本时出现编码错误：
```
UnicodeDecodeError: 'gbk' codec can't decode byte 0xba in position 55: illegal multibyte sequence
```

## 问题分析

### 根本原因
1. **Windows默认编码**: Windows系统默认使用GBK编码
2. **Playwright输出编码**: Playwright可能输出UTF-8编码的字符
3. **编码不匹配**: Python尝试用GBK解码UTF-8内容导致失败

### 错误位置
```python
result = subprocess.run(
    command_str,
    capture_output=True,
    text=True,  # 使用系统默认编码（Windows上是GBK）
    shell=True
)
```

### 错误堆栈
```
File "subprocess.py", line 1599, in _readerthread
    buffer.append(fh.read())
UnicodeDecodeError: 'gbk' codec can't decode byte 0xba in position 55
```

## 修复方案

### 1. 主要方案：强制UTF-8编码

```python
# 设置UTF-8编码环境变量
env_with_utf8 = env.copy()
env_with_utf8['PYTHONIOENCODING'] = 'utf-8'
env_with_utf8['CHCP'] = '65001'  # 设置代码页为UTF-8

result = subprocess.run(
    command_str,
    cwd=self.playwright_workspace,
    capture_output=True,
    text=True,
    env=env_with_utf8,
    timeout=300,
    shell=True,
    encoding='utf-8',  # 明确指定UTF-8编码
    errors='replace'  # 遇到编码错误时替换为占位符
)
```

### 2. 备用方案：字节模式 + 智能解码

```python
except UnicodeDecodeError as e:
    logger.warning(f"编码错误，尝试使用字节模式: {str(e)}")
    
    # 使用字节模式重新执行
    result = subprocess.run(
        command_str,
        capture_output=True,
        text=False,  # 字节模式
        env=env_with_utf8,
        timeout=300,
        shell=True
    )
    
    # 智能解码函数
    def safe_decode(byte_data):
        if not byte_data:
            return []
        try:
            return byte_data.decode('utf-8').splitlines()
        except UnicodeDecodeError:
            try:
                return byte_data.decode('gbk').splitlines()
            except UnicodeDecodeError:
                return byte_data.decode('utf-8', errors='replace').splitlines()
    
    stdout_lines = safe_decode(result.stdout)
    stderr_lines = safe_decode(result.stderr)
```

## 修复策略

### 1. 多层编码处理
1. **第一层**: 设置UTF-8环境变量和编码参数
2. **第二层**: 如果UTF-8失败，使用字节模式
3. **第三层**: 智能解码，依次尝试UTF-8、GBK、容错UTF-8

### 2. 环境变量设置
```python
env_with_utf8 = env.copy()
env_with_utf8['PYTHONIOENCODING'] = 'utf-8'  # Python IO编码
env_with_utf8['CHCP'] = '65001'              # Windows代码页UTF-8
```

### 3. 容错机制
```python
encoding='utf-8',     # 明确指定编码
errors='replace'      # 编码错误时用占位符替换
```

## 修复后的完整代码

```python
# Windows系统使用同步subprocess，需要shell=True来执行npx
try:
    # 在Windows上将命令转换为字符串并使用shell=True
    command_str = ' '.join(command)
    logger.info(f"Windows执行命令: {command_str}")
    
    # 设置UTF-8编码环境变量，避免Windows编码问题
    env_with_utf8 = env.copy()
    env_with_utf8['PYTHONIOENCODING'] = 'utf-8'
    env_with_utf8['CHCP'] = '65001'  # 设置代码页为UTF-8
    
    result = subprocess.run(
        command_str,
        cwd=self.playwright_workspace,
        capture_output=True,
        text=True,
        env=env_with_utf8,
        timeout=300,  # 5分钟超时
        shell=True,  # Windows上需要shell=True来执行npx
        encoding='utf-8',  # 明确指定UTF-8编码
        errors='replace'  # 遇到编码错误时替换为占位符
    )
    
    return_code = result.returncode
    stdout_lines = result.stdout.splitlines() if result.stdout else []
    stderr_lines = result.stderr.splitlines() if result.stderr else []
    
    # 记录和发送输出信息
    for line in stdout_lines:
        if line.strip():
            record["logs"].append(f"[STDOUT] {line}")
            await self.send_response(f"📝 {line}")
            logger.info(f"[Playwright] {line}")
    
    for line in stderr_lines:
        if line.strip():
            record["logs"].append(f"[STDERR] {line}")
            await self.send_response(f"⚠️ {line}")
            logger.warning(f"[Playwright Error] {line}")
            
except subprocess.TimeoutExpired:
    logger.error("Playwright测试执行超时")
    raise Exception("测试执行超时（5分钟）")
    
except UnicodeDecodeError as e:
    logger.warning(f"编码错误，尝试使用字节模式: {str(e)}")
    
    # 如果UTF-8编码失败，使用字节模式重新执行
    try:
        result = subprocess.run(
            command_str,
            cwd=self.playwright_workspace,
            capture_output=True,
            text=False,  # 使用字节模式
            env=env_with_utf8,
            timeout=300,
            shell=True
        )
        
        return_code = result.returncode
        
        # 手动处理编码，优先尝试UTF-8，失败则使用GBK
        def safe_decode(byte_data):
            if not byte_data:
                return []
            try:
                return byte_data.decode('utf-8').splitlines()
            except UnicodeDecodeError:
                try:
                    return byte_data.decode('gbk').splitlines()
                except UnicodeDecodeError:
                    return byte_data.decode('utf-8', errors='replace').splitlines()
        
        stdout_lines = safe_decode(result.stdout)
        stderr_lines = safe_decode(result.stderr)
        
    except Exception as inner_e:
        logger.error(f"字节模式执行也失败: {str(inner_e)}")
        raise Exception(f"执行失败: {str(inner_e)}")
        
except Exception as e:
    logger.error(f"Playwright测试执行出错：{str(e)}")
    raise
```

## 技术要点

### 1. Windows编码设置
```bash
# 设置Windows控制台为UTF-8
chcp 65001

# 设置Python IO编码
set PYTHONIOENCODING=utf-8
```

### 2. 编码优先级
1. **UTF-8**: 现代标准，支持所有字符
2. **GBK**: Windows中文默认编码
3. **容错UTF-8**: 用占位符替换无法解码的字符

### 3. 字节模式处理
```python
# 文本模式（可能失败）
result = subprocess.run(..., text=True)

# 字节模式（更可靠）
result = subprocess.run(..., text=False)
decoded_output = result.stdout.decode('utf-8', errors='replace')
```

## 验证方法

### 1. 编码测试
```python
# 测试不同编码的字符
test_chars = "Hello 世界 🎭 ✅"
print(f"UTF-8: {test_chars.encode('utf-8')}")
print(f"GBK: {test_chars.encode('gbk', errors='replace')}")
```

### 2. 环境变量验证
```python
import os
print(f"PYTHONIOENCODING: {os.environ.get('PYTHONIOENCODING')}")
print(f"CHCP: {os.environ.get('CHCP')}")
```

### 3. 执行结果验证
确保以下内容正常显示：
- Playwright执行日志
- 测试结果统计
- 错误信息（如果有）
- 中文字符（如果有）

## 预期结果

修复后应该看到：
```
INFO: Windows执行命令: npx playwright test e2e/test_20250608_121848.spec.ts
INFO: [Playwright] Running 1 test using 1 worker
INFO: [Playwright] ✓ e2e/test_20250608_121848.spec.ts:3:1 › example test (2.5s)
INFO: [Playwright] 1 passed (3.2s)
INFO: Playwright测试执行完成: passed
```

而不是：
```
ERROR: UnicodeDecodeError: 'gbk' codec can't decode byte 0xba in position 55
```

## 修改文件清单

### 后端文件
- `backend/app/agents/web/playwright_executor.py`
  - 第304-319行: 添加UTF-8编码设置
  - 第338-378行: 添加编码错误处理和字节模式备用方案

## 总结

这次修复解决了Windows系统上的编码问题：

1. ✅ **主要方案**: 强制使用UTF-8编码和环境变量设置
2. ✅ **备用方案**: 字节模式 + 智能解码
3. ✅ **容错机制**: 多种编码尝试和错误替换
4. ✅ **环境优化**: 设置Windows代码页和Python IO编码

修复后，Windows系统上的Playwright执行应该不再出现编码相关的错误。
