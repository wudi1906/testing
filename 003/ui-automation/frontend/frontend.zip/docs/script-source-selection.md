# 脚本来源选择功能文档

## 功能概述

在Web执行测试页面添加了脚本来源选择功能，用户可以选择从不同来源加载脚本：
- **全部**: 同时显示数据库和磁盘目录中的脚本
- **数据库**: 只显示存储在MySQL数据库中的脚本
- **磁盘目录**: 只显示来自文件系统的脚本

## 功能特性

### 1. 脚本来源选择器
- 位置：搜索和操作栏中
- 样式：Radio按钮组，紧凑布局
- 选项：全部、数据库、磁盘目录
- 默认：全部

### 2. 脚本来源标识
- 数据库脚本：蓝色标签 "数据库"
- 磁盘脚本：绿色标签 "磁盘目录"
- 显示位置：脚本名称下方

### 3. 统计信息更新
- 总脚本数：当前显示的脚本总数
- 数据库脚本：数据库来源的脚本数量
- 磁盘脚本：文件系统来源的脚本数量
- 活动执行：当前正在执行的任务数

## 技术实现

### 1. 状态管理
```typescript
// 脚本来源选择状态
const [scriptSource, setScriptSource] = useState<'all' | 'database' | 'filesystem'>('all');

// Script接口扩展
interface Script {
  id: string;
  name: string;
  type?: 'database' | 'filesystem'; // 新增：脚本来源类型
  // ... 其他字段
}
```

### 2. 数据加载逻辑
```typescript
// 根据来源加载脚本
const loadScriptsBySource = useCallback(async () => {
  let allScripts: Script[] = [];

  if (scriptSource === 'all' || scriptSource === 'database') {
    // 加载数据库脚本
    const dbScripts = await loadDatabaseScripts();
    allScripts = [...allScripts, ...dbScripts];
  }

  if (scriptSource === 'all' || scriptSource === 'filesystem') {
    // 加载文件系统脚本
    const fsScripts = await loadFileSystemScripts();
    allScripts = [...allScripts, ...fsScripts];
  }

  setScripts(allScripts);
}, [scriptSource, loadDatabaseScripts, loadFileSystemScripts]);
```

### 3. 脚本类型标记
```typescript
// 数据库脚本标记
const dbScripts: Script[] = scriptsData.scripts.map((script: any) => ({
  id: script.id,
  name: script.name,
  type: 'database' as const, // 标记为数据库来源
  // ... 其他字段
}));

// 文件系统脚本标记
const fsScripts: Script[] = scriptsData.scripts.map((script: any) => ({
  id: script.name,
  name: script.name,
  type: 'filesystem' as const, // 标记为文件系统来源
  // ... 其他字段
}));
```

### 4. UI组件
```typescript
// 脚本来源选择器
<div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
  <Typography.Text strong style={{ fontSize: 12, whiteSpace: 'nowrap' }}>
    脚本来源:
  </Typography.Text>
  <Radio.Group
    value={scriptSource}
    onChange={(e) => setScriptSource(e.target.value)}
    size="small"
    buttonStyle="solid"
  >
    <Radio.Button value="all">全部</Radio.Button>
    <Radio.Button value="database">数据库</Radio.Button>
    <Radio.Button value="filesystem">磁盘目录</Radio.Button>
  </Radio.Group>
</div>

// 脚本来源标识
{record.type === 'database' ? (
  <Tag size="small" color="blue">数据库</Tag>
) : (
  <Tag size="small" color="green">磁盘目录</Tag>
)}
```

## 数据流程

### 1. 初始化流程
```
页面加载 → 默认选择"全部" → 加载数据库脚本 → 加载文件系统脚本 → 合并显示
```

### 2. 来源切换流程
```
用户选择来源 → 触发useEffect → 重新加载对应来源脚本 → 更新列表和统计
```

### 3. 脚本执行流程
```
用户点击执行 → 根据脚本类型调用对应API → 执行脚本 → 保存报告
```

## API集成

### 1. 数据库脚本API
- 接口：`/api/v1/web/script-management/search`
- 来源：MySQL数据库
- 特点：支持搜索、分页、标签等高级功能

### 2. 文件系统脚本API
- 接口：`/api/v1/web/script-execution/available-scripts`
- 来源：磁盘目录
- 特点：实时读取文件系统，显示文件信息

### 3. 统一执行API
- 接口：`/api/v1/web/script-execution/execute`
- 支持：根据脚本ID执行，自动识别来源
- 报告：统一保存到MySQL数据库

## 用户体验

### 1. 界面布局
- **紧凑设计**: 脚本来源选择器与搜索框在同一行
- **视觉区分**: 不同来源的脚本有明显的颜色标识
- **实时统计**: 统计信息根据当前显示的脚本动态更新

### 2. 交互体验
- **即时响应**: 切换来源后立即重新加载脚本
- **状态保持**: 选择的来源在页面刷新前保持不变
- **错误提示**: 加载失败时显示友好的错误信息

### 3. 性能优化
- **按需加载**: 只加载选中来源的脚本
- **缓存机制**: 避免重复请求相同数据
- **异步加载**: 不阻塞UI响应

## 使用场景

### 1. 开发阶段
- 选择"磁盘目录"查看和执行本地开发的脚本
- 实时测试新编写的脚本文件

### 2. 生产环境
- 选择"数据库"执行已发布的稳定脚本
- 利用数据库脚本的版本管理和元数据功能

### 3. 混合使用
- 选择"全部"查看所有可用脚本
- 对比数据库和文件系统中的脚本差异

## 配置说明

### 1. 默认设置
```typescript
// 默认显示所有来源的脚本
const [scriptSource, setScriptSource] = useState<'all' | 'database' | 'filesystem'>('all');
```

### 2. 自定义配置
可以通过修改初始状态来改变默认行为：
```typescript
// 默认只显示数据库脚本
const [scriptSource, setScriptSource] = useState<'all' | 'database' | 'filesystem'>('database');

// 默认只显示磁盘脚本
const [scriptSource, setScriptSource] = useState<'all' | 'database' | 'filesystem'>('filesystem');
```

## 扩展功能

### 1. 可能的扩展
- **收藏夹**: 添加收藏的脚本来源
- **最近使用**: 显示最近执行的脚本
- **分组显示**: 按项目或类别分组显示脚本

### 2. 高级过滤
- **组合过滤**: 来源 + 标签 + 状态的组合过滤
- **保存过滤**: 保存常用的过滤条件
- **快速切换**: 预设的过滤方案快速切换

## 总结

脚本来源选择功能提供了灵活的脚本管理方式：

1. ✅ **多来源支持**: 统一管理数据库和文件系统脚本
2. ✅ **可视化区分**: 清晰的标签标识不同来源
3. ✅ **实时统计**: 动态显示各来源脚本数量
4. ✅ **用户友好**: 简洁的界面和流畅的交互
5. ✅ **性能优化**: 按需加载，避免不必要的请求

这个功能让用户可以根据需要选择合适的脚本来源，提高了测试执行的灵活性和效率。
