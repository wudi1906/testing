# Web模块前后端集成优化文档

## 概述

本次优化整合了脚本管理接口和脚本执行接口，实现了前端Web执行测试界面的全面前后端集成，支持数据库脚本管理和文件系统脚本执行两种模式。

## 后端接口分析

### 1. 脚本管理接口 (`script_management.py`)

#### 主要功能
- **脚本CRUD操作**: 创建、读取、更新、删除数据库中的脚本
- **脚本搜索**: 支持多条件搜索和分页
- **脚本统计**: 提供脚本数量、执行次数等统计信息
- **文件上传**: 支持YAML和Playwright脚本文件上传
- **批量操作**: 支持批量执行数据库脚本

#### 核心端点
```
POST   /web/scripts/search           # 搜索脚本
GET    /web/scripts/statistics       # 获取统计信息
GET    /web/scripts/{script_id}      # 获取脚本详情
PUT    /web/scripts/{script_id}      # 更新脚本
DELETE /web/scripts/{script_id}      # 删除脚本
POST   /web/scripts/{script_id}/execute  # 执行脚本
POST   /web/scripts/batch-execute   # 批量执行
POST   /web/scripts/upload          # 上传脚本文件
POST   /web/scripts/save-from-session  # 从会话保存脚本
```

### 2. 脚本执行接口 (`script_execution.py`)

#### 主要功能
- **文件系统脚本管理**: 获取工作空间中的.spec.ts文件
- **实时执行**: 支持单个和批量脚本执行
- **SSE流式通信**: 实时推送执行状态和日志
- **会话管理**: 管理执行会话的生命周期
- **报告生成**: 自动生成和管理测试报告

#### 核心端点
```
GET    /web/scripts/scripts          # 获取可用脚本列表
GET    /web/scripts/workspace/info   # 获取工作空间信息
POST   /web/scripts/execute/single   # 执行单个脚本
POST   /web/scripts/execute/batch    # 批量执行脚本
GET    /web/scripts/stream/{session_id}  # SSE实时状态流
GET    /web/scripts/sessions         # 获取会话列表
POST   /web/scripts/sessions/{session_id}/stop  # 停止执行
GET    /web/scripts/reports/{session_id}  # 获取报告
```

## 前端集成优化

### 1. API服务层优化

#### 统一的API函数命名
```typescript
// 数据库脚本管理
searchScripts()              // 搜索数据库脚本
getScriptStatistics()        // 获取统计信息
executeScriptFromDB()        // 执行数据库脚本
batchExecuteScriptsFromDB()  // 批量执行数据库脚本
uploadScriptFile()           // 上传脚本文件

// 文件系统脚本执行
getAvailableScripts()        // 获取文件系统脚本
getWorkspaceInfo()           // 获取工作空间信息
executeSingleScript()        // 执行文件系统脚本
executeBatchScripts()        // 批量执行文件系统脚本
createScriptExecutionSSE()   // 创建SSE连接
```

#### 类型定义优化
```typescript
// 数据库脚本类型
interface DatabaseScript {
  id: string;
  name: string;
  description: string;
  content: string;
  script_format: string;
  script_type: string;
  category?: string;
  tags: string[];
  execution_count: number;
  created_at: string;
  updated_at: string;
}

// 文件系统脚本类型
interface FileSystemScript {
  name: string;
  path: string;
  size: number;
  modified: string;
}

// 联合类型
type Script = DatabaseScript | FileSystemScript;
```

### 2. 组件层优化

#### ScriptManagementTab 组件
- **双数据源支持**: 数据库脚本 + 文件系统脚本
- **智能切换**: 根据脚本源动态调整UI和功能
- **统一操作**: 执行、查看、删除等操作的统一接口
- **实时统计**: 显示不同数据源的统计信息

```typescript
// 脚本源选择
const [scriptSource, setScriptSource] = useState<'database' | 'filesystem'>('database');

// 根据脚本源加载数据
const loadScripts = useCallback(async () => {
  if (scriptSource === 'database') {
    await loadDatabaseScripts();
  } else {
    await loadFileSystemScripts();
  }
}, [scriptSource]);

// 统一执行接口
const handleExecuteScript = async (script: Script) => {
  if (isDatabaseScript(script)) {
    await executeScriptFromDB(script.id, config);
  } else {
    await executeSingleScript({ script_name: script.name, ...config });
  }
};
```

#### QuickExecutionTab 组件
- **多执行模式**: 现有脚本、上传文件、输入内容
- **脚本源选择**: 支持数据库和文件系统脚本选择
- **智能配置**: 根据脚本类型调整配置选项
- **实时预览**: 脚本内容和描述的实时预览

#### ExecutionStatusPanel 组件
- **SSE实时连接**: 自动建立和管理SSE连接
- **多消息类型**: 支持各种执行状态和日志消息
- **智能显示**: 根据消息类型动态调整显示样式
- **报告管理**: 自动收集和展示测试报告

### 3. 状态管理优化

#### 统一状态结构
```typescript
interface ExecutionState {
  // 脚本源和数据
  scriptSource: 'database' | 'filesystem';
  scripts: Script[];
  statistics: any;
  workspaceInfo: any;
  
  // 执行状态
  currentSessionId: string | null;
  currentScriptName: string | null;
  executionCount: number;
  
  // UI状态
  loading: boolean;
  selectedScripts: string[];
  showStatusPanel: boolean;
}
```

#### 类型守卫函数
```typescript
const isDatabaseScript = (script: Script): script is DatabaseScript => {
  return 'id' in script;
};

const isFileSystemScript = (script: Script): script is FileSystemScript => {
  return 'path' in script;
};
```

## 功能特性

### 1. 双数据源支持
- **数据库脚本**: 持久化存储，支持元数据管理
- **文件系统脚本**: 直接读取工作空间文件，支持实时同步
- **无缝切换**: 用户可以在两种数据源间自由切换

### 2. 统一执行接口
- **单脚本执行**: 支持两种数据源的单脚本执行
- **批量执行**: 支持串行和并行执行模式
- **实时监控**: SSE实时推送执行状态和日志
- **报告管理**: 自动生成和管理测试报告

### 3. 智能UI适配
- **动态表格**: 根据数据源调整表格列和操作
- **条件渲染**: 根据脚本类型显示不同的信息和操作
- **响应式设计**: 适配不同屏幕尺寸和设备

### 4. 高级功能
- **脚本搜索**: 支持名称、描述、标签等多条件搜索
- **统计分析**: 提供脚本数量、执行次数等统计信息
- **文件上传**: 支持拖拽上传和批量上传
- **配置管理**: 灵活的执行配置和环境变量设置

## 技术亮点

### 1. 类型安全
- **TypeScript**: 完整的类型定义和类型检查
- **类型守卫**: 运行时类型检查和类型收窄
- **接口统一**: 统一的API接口和数据结构

### 2. 性能优化
- **懒加载**: 按需加载脚本数据和组件
- **缓存策略**: 智能缓存脚本列表和配置信息
- **防抖搜索**: 优化搜索性能和用户体验

### 3. 错误处理
- **统一错误处理**: 一致的错误提示和恢复机制
- **网络重试**: 自动重试失败的网络请求
- **状态恢复**: 支持连接断开后的状态恢复

### 4. 用户体验
- **实时反馈**: Toast提示和实时状态更新
- **加载状态**: 完善的加载指示器和骨架屏
- **操作确认**: 重要操作的确认对话框

## 使用流程

### 1. 脚本管理流程
```
选择脚本源 → 加载脚本列表 → 搜索/筛选 → 选择脚本 → 执行/管理
```

### 2. 快速执行流程
```
选择执行模式 → 配置脚本源 → 选择/上传/输入脚本 → 配置参数 → 执行
```

### 3. 状态监控流程
```
建立SSE连接 → 实时接收状态 → 显示执行进度 → 查看日志/报告
```

## 扩展性设计

### 1. 插件化架构
- **数据源插件**: 支持添加新的脚本数据源
- **执行器插件**: 支持不同类型的脚本执行器
- **UI组件插件**: 支持自定义UI组件和主题

### 2. 配置化设计
- **动态配置**: 支持运行时配置修改
- **环境适配**: 支持不同环境的配置切换
- **用户偏好**: 支持用户个性化设置

### 3. 国际化支持
- **多语言**: 支持中英文等多语言切换
- **本地化**: 支持不同地区的格式和习惯
- **动态加载**: 按需加载语言包

## 总结

通过本次前后端集成优化，Web模块的脚本执行功能实现了：

- ✅ **双数据源支持**: 数据库脚本管理 + 文件系统脚本执行
- ✅ **统一用户界面**: 一致的操作体验和视觉设计
- ✅ **实时状态监控**: SSE实时推送和状态更新
- ✅ **类型安全保障**: 完整的TypeScript类型系统
- ✅ **高性能优化**: 懒加载、缓存、防抖等优化策略
- ✅ **良好扩展性**: 插件化架构和配置化设计

这为用户提供了一个功能完整、性能优秀、体验良好的脚本管理和执行平台。
